import javax.crypto.IllegalBlockSizeException;
import javax.swing.*;

public class ComputerPlayer extends Player {

	public ComputerPlayer() {
		super("Computer");
	}

	@Override
	public void takeTurn() {

	}
}
